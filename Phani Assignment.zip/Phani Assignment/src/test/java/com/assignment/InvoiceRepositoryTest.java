package com.assignment;

import com.assignment.model.Invoice;
import com.assignment.repository.InvoiceRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@DataJpaTest
public class InvoiceRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private InvoiceRepository invoiceRepository;

    @Test
    public void testFindByName() {
        entityManager.persist(new Invoice("Discovery",15L,new Date()));
        List<Invoice> invoices = invoiceRepository.findByClient("Discovery");
        assertEquals(1, invoices.size());
        assertThat(invoices).extracting(Invoice::getClient).containsOnly("Discovery");
    }

}
